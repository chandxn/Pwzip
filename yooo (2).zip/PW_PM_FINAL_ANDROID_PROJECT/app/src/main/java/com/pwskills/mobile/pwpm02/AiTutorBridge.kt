package com.pwskills.mobile.pwpm02

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AiTutorBridge.kt
 * Bridges the local ai_tutor.html UI to the user's configured LLM provider
 * (Gemini API or OpenAI-compatible API) using OkHttp on Dispatchers.IO,
 * and persists per-lesson study task checklists locally in SharedPreferences.
 */
class AiTutorBridge(
    private val activity: MainActivity,
    private val aiWebView: WebView
) {
    private val prefs = activity.getSharedPreferences("pw_ai_tutor_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    @JavascriptInterface
    fun saveLlmConfig(provider: String?, apiKey: String?, model: String?, language: String?): String {
        val cleanProvider = (provider ?: "gemini").trim().lowercase()
        val cleanModel = (model ?: defaultModelFor(cleanProvider)).trim()
        val cleanLang = (language ?: "Hinglish").trim()
        val editor = prefs.edit()
            .putString("llm_provider", cleanProvider)
            .putString("llm_model", cleanModel)
            .putString("tutor_language", cleanLang)

        val trimmedKey = apiKey?.trim() ?: ""
        if (trimmedKey.isNotEmpty() && !trimmedKey.startsWith("••••")) {
            editor.putString("llm_api_key", trimmedKey)
        }
        editor.apply()
        return getLlmConfig()
    }

    @JavascriptInterface
    fun clearApiKey(): String {
        prefs.edit().remove("llm_api_key").apply()
        return getLlmConfig()
    }

    @JavascriptInterface
    fun getLlmConfig(): String {
        val provider = prefs.getString("llm_provider", "gemini") ?: "gemini"
        val model = prefs.getString("llm_model", defaultModelFor(provider)) ?: defaultModelFor(provider)
        val language = prefs.getString("tutor_language", "Hinglish") ?: "Hinglish"
        val key = prefs.getString("llm_api_key", "") ?: ""
        val masked = if (key.length > 8) "••••" + key.takeLast(4) else if (key.isNotEmpty()) "••••" else ""

        return JSONObject().apply {
            put("provider", provider)
            put("model", model)
            put("language", language)
            put("hasKey", key.isNotEmpty())
            put("maskedKey", masked)
        }.toString()
    }

    @JavascriptInterface
    fun saveStudyTasks(lessonId: String?, tasksJson: String?) {
        if (lessonId.isNullOrBlank()) return
        prefs.edit().putString("tasks_$lessonId", tasksJson ?: "[]").apply()
    }

    @JavascriptInterface
    fun getStudyTasks(lessonId: String?): String {
        if (lessonId.isNullOrBlank()) return "[]"
        return prefs.getString("tasks_$lessonId", "[]") ?: "[]"
    }

    @JavascriptInterface
    fun askLlm(requestId: String?, systemInstruction: String?, userPrompt: String?) {
        val reqId = (requestId ?: "").trim()
        val sys = (systemInstruction ?: "").trim()
        val prompt = (userPrompt ?: "").trim()

        val apiKey = prefs.getString("llm_api_key", "")?.trim() ?: ""
        val provider = prefs.getString("llm_provider", "gemini") ?: "gemini"
        val model = prefs.getString("llm_model", defaultModelFor(provider)) ?: defaultModelFor(provider)

        if (apiKey.isEmpty()) {
            deliverToWebView(reqId, ok = false, text = "", error = "NO_API_KEY_CONFIGURED")
            return
        }
        if (prompt.isEmpty()) {
            deliverToWebView(reqId, ok = false, text = "", error = "EMPTY_PROMPT")
            return
        }

        scope.launch {
            try {
                val reply = when (provider) {
                    "openai" -> callOpenAi(apiKey, model, sys, prompt)
                    else -> callGemini(apiKey, model, sys, prompt)
                }
                deliverToWebView(reqId, ok = true, text = reply, error = "")
            } catch (e: Exception) {
                deliverToWebView(reqId, ok = false, text = "", error = e.message ?: "LLM_REQUEST_FAILED")
            }
        }
    }

    private fun callGemini(apiKey: String, model: String, systemText: String, userText: String): String {
        val safeModel = model.ifBlank { "gemini-2.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent?key=$apiKey"

        val bodyJson = JSONObject().apply {
            if (systemText.isNotBlank()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemText)))
                })
            }
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userText)))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.35)
                put("maxOutputTokens", 2048)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val msg = try {
                    JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw
                } catch (_: Exception) {
                    raw
                }
                throw IllegalStateException("Gemini HTTP ${response.code}: $msg")
            }
            val json = JSONObject(raw)
            val candidates = json.optJSONArray("candidates")
                ?: throw IllegalStateException("No candidates returned by Gemini.")
            if (candidates.length() == 0) {
                throw IllegalStateException("Empty candidates returned by Gemini.")
            }
            val parts = candidates.getJSONObject(0)
                .optJSONObject("content")
                ?.optJSONArray("parts")
                ?: throw IllegalStateException("Missing content parts in Gemini response.")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val t = parts.getJSONObject(i).optString("text", "")
                if (t.isNotEmpty()) sb.append(t)
            }
            return sb.toString().trim()
        }
    }

    private fun callOpenAi(apiKey: String, model: String, systemText: String, userText: String): String {
        val safeModel = model.ifBlank { "gpt-4o-mini" }
        val url = "https://api.openai.com/v1/chat/completions"

        val messages = JSONArray()
        if (systemText.isNotBlank()) {
            messages.put(JSONObject().put("role", "system").put("content", systemText))
        }
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val bodyJson = JSONObject().apply {
            put("model", safeModel)
            put("messages", messages)
            put("temperature", 0.35)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val msg = try {
                    JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw
                } catch (_: Exception) {
                    raw
                }
                throw IllegalStateException("OpenAI HTTP ${response.code}: $msg")
            }
            val json = JSONObject(raw)
            val choices = json.optJSONArray("choices")
                ?: throw IllegalStateException("No choices returned by OpenAI.")
            if (choices.length() == 0) {
                throw IllegalStateException("Empty choices returned by OpenAI.")
            }
            return choices.getJSONObject(0)
                .optJSONObject("message")
                ?.optString("content", "")
                ?.trim()
                ?: ""
        }
    }

    private fun deliverToWebView(requestId: String, ok: Boolean, text: String, error: String) {
        val payload = JSONObject().apply {
            put("requestId", requestId)
            put("ok", ok)
            put("text", text)
            put("error", error)
        }.toString()

        activity.runOnUiThread {
            aiWebView.evaluateJavascript(
                "window.__onAiTutorResponse&&window.__onAiTutorResponse($payload);",
                null
            )
        }
    }

    fun shutdown() {
        scope.cancel()
    }

    companion object {
        fun defaultModelFor(provider: String): String {
            return if (provider == "openai") "gpt-4o-mini" else "gemini-2.5-flash"
        }
    }
}
