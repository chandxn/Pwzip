plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ciRunNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
val computedVersionCode = 2400 + ciRunNumber

android {
    namespace = "com.pwskills.mobile.pwpm02"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pwskills.mobile.pwpm02"
        minSdk = 24
        targetSdk = 34
        versionCode = computedVersionCode
        versionName = "24.$ciRunNumber"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        create("sharedDev") {
            storeFile = file("pw-dev-signing.jks")
            storePassword = "pwdev1234"
            keyAlias = "pwdev"
            keyPassword = "pwdev1234"
        }
    }

    flavorDimensions += "course"
    productFlavors {
        create("dm") {
            dimension = "course"
            applicationId = "com.pwskills.mobile.pwdm"
            resValue("string", "app_name", "PW-DM")
            resValue("string", "download_channel_name", "PW-DM Offline Downloads")
            buildConfigField("String", "APK_ASSET_NAME", "\"PW-DM-debug.apk\"")
        }
        create("pm") {
            dimension = "course"
            applicationId = "com.pwskills.mobile.pwpm02"
            resValue("string", "app_name", "PW-PM")
            resValue("string", "download_channel_name", "PW-PM Offline Downloads")
            buildConfigField("String", "APK_ASSET_NAME", "\"PW-PM-debug.apk\"")
        }
        create("fswd") {
            dimension = "course"
            applicationId = "com.pwskills.mobile.pwfswd"
            resValue("string", "app_name", "PW-FSWD")
            resValue("string", "download_channel_name", "PW-FSWD Offline Downloads")
            buildConfigField("String", "APK_ASSET_NAME", "\"PW-FSWD-debug.apk\"")
        }
        create("ds") {
            dimension = "course"
            applicationId = "com.pwskills.mobile.pwds"
            resValue("string", "app_name", "PW-DS")
            resValue("string", "download_channel_name", "PW-DS Offline Downloads")
            buildConfigField("String", "APK_ASSET_NAME", "\"PW-DS-debug.apk\"")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("sharedDev")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("sharedDev")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf("-opt-in=androidx.media3.common.util.UnstableApi")
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    val media3Version = "1.3.1"

    // AndroidX Core, Annotation & WebKit
    implementation("androidx.annotation:annotation:1.8.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // WorkManager for progressive/direct file downloads & MediaStore verification
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Official AndroidX Media3 1.3.1 for ExoPlayer, HLS, DASH, Widevine OfflineLicenseHelper & DownloadService
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-exoplayer-workmanager:$media3Version")
    implementation("androidx.media3:media3-datasource:$media3Version")
    implementation("androidx.media3:media3-database:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")

    // Networking & Unit Testing
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
}
