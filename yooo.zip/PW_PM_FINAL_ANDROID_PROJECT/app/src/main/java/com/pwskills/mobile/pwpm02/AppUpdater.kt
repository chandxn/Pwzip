package com.pwskills.mobile.pwpm02

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * AppUpdater.kt
 * Checks GitHub Releases (`chandxn/Pwzip`) for a newer versionCode and installs
 * the matching flavor APK in-place via FileProvider (preserving login cookies & data).
 */
object AppUpdater {
    private const val RELEASES_LATEST_URL = "https://api.github.com/repos/chandxn/Pwzip/releases/latest"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun checkForUpdate(activity: Activity, silentIfUpToDate: Boolean = true) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val req = Request.Builder()
                    .url(RELEASES_LATEST_URL)
                    .header("Accept", "application/vnd.github+json")
                    .build()

                val releaseJson = client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use null
                    JSONObject(resp.body?.string() ?: return@use null)
                } ?: return@launch

                val tag = releaseJson.optString("tag_name", "")
                val remoteVersionCode = parseVersionCodeFromTag(tag)
                if (remoteVersionCode <= BuildConfig.VERSION_CODE) {
                    if (!silentIfUpToDate) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(activity, "App is up to date (v${BuildConfig.VERSION_CODE})", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return@launch
                }

                val assets = releaseJson.optJSONArray("assets") ?: return@launch
                var downloadUrl = ""
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.optString("name") == BuildConfig.APK_ASSET_NAME) {
                        downloadUrl = asset.optString("browser_download_url", "")
                        break
                    }
                }
                if (downloadUrl.isBlank()) return@launch

                withContext(Dispatchers.Main) {
                    if (activity.isFinishing || activity.isDestroyed) return@withContext
                    AlertDialog.Builder(activity)
                        .setTitle("Update Available ($tag)")
                        .setMessage("A newer version of ${BuildConfig.APK_ASSET_NAME.removeSuffix("-debug.apk")} is ready. Update in-place without losing your login?")
                        .setPositiveButton("Update Now") { _, _ ->
                            downloadAndInstall(activity, downloadUrl)
                        }
                        .setNegativeButton("Later", null)
                        .show()
                }
            } catch (_: Exception) {
                if (!silentIfUpToDate) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(activity, "Unable to check updates right now.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun downloadAndInstall(activity: Activity, url: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(activity, "Allow 'Install unknown apps' for in-app updates, then tap Update again.", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
            activity.startActivity(intent)
            return
        }

        Toast.makeText(activity, "Downloading update...", Toast.LENGTH_SHORT).show()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val outFile = File(activity.cacheDir, "pw_update.apk")
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                    val body = resp.body ?: throw IllegalStateException("Empty body")
                    FileOutputStream(outFile).use { fos ->
                        body.byteStream().copyTo(fos)
                    }
                }

                withContext(Dispatchers.Main) {
                    val apkUri = FileProvider.getUriForFile(
                        activity,
                        "${activity.packageName}.fileprovider",
                        outFile
                    )
                    val installIntent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(apkUri, "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    activity.startActivity(installIntent)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "Update failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun parseVersionCodeFromTag(tag: String): Int {
        // Expects tag like "v2400.55" or "v2455" -> extracts integer 2455
        val digits = tag.replace("v", "", ignoreCase = true)
        val parts = digits.split(".")
        if (parts.size == 2) {
            val major = parts[0].toIntOrNull() ?: return 0
            val run = parts[1].toIntOrNull() ?: return 0
            return major + run
        }
        return digits.toIntOrNull() ?: 0
    }
}
