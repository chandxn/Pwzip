package com.pwskills.mobile.pwpm02

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Message
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * Standalone File: MainActivity.kt
 * Integrated with ActiveLessonState, PwPortalProviderAdapter, NativeDownloadBridge,
 * AiTutorBridge, PwOfflinePlayer, persistent CookieManager, and OAuth popup WebView support.
 */
class MainActivity : Activity(), View.OnClickListener {

    lateinit var portalWebView: WebView
    lateinit var playerWebView: WebView
    lateinit var aiTutorWebView: WebView

    private lateinit var contentFrame: FrameLayout
    private val popupWebViews = mutableListOf<WebView>()

    private lateinit var tabPortalBtn: Button
    private lateinit var tabPlayerBtn: Button
    private lateinit var tabAiBtn: Button

    private lateinit var repository: DownloadRepository
    private lateinit var providerAdapter: PwPortalProviderAdapter
    private lateinit var downloadBridge: NativeDownloadBridge
    private lateinit var aiTutorBridge: AiTutorBridge
    private lateinit var offlinePlayer: PwOfflinePlayer

    private var canonicalLessonState: ActiveLessonState? = null
    private var latestSessionJson: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        repository = DownloadRepository.getInstance(this)
        providerAdapter = PwPortalProviderAdapter(this, repository)
        offlinePlayer = PwOfflinePlayer(this)

        // Ensure WebView cookies are persisted across app restarts
        CookieManager.getInstance().setAcceptCookie(true)

        // Restore persisted canonical session if valid (ignoring legacy dashboard noise)
        val cachedJson = getSharedPreferences("pw_pm_v21_session", MODE_PRIVATE)
            .getString("session_json", "") ?: ""
        val parsedState = ActiveLessonState.fromPortalJsonOrNull(cachedJson)
        if (parsedState != null) {
            canonicalLessonState = parsedState
            latestSessionJson = cachedJson
            providerAdapter.registerSyncedLesson(parsedState.toLessonMetadata())
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#070B14"))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            gravity = Gravity.CENTER
        }

        tabPortalBtn = createNavButton("★ PW Portal", 1001, "#059669")
        tabPlayerBtn = createNavButton("▶ Course Player", 1002, "#2563EB")
        tabAiBtn = createNavButton("✨ AI Tutor", 1003, "#7C3AED")
        val updateBtn = createNavButton("↻", 1004, "#1E293B")

        topBar.addView(tabPortalBtn, LinearLayout.LayoutParams(0, dp(44), 1f))
        topBar.addView(tabPlayerBtn, LinearLayout.LayoutParams(0, dp(44), 1f))
        topBar.addView(tabAiBtn, LinearLayout.LayoutParams(0, dp(44), 1f))
        topBar.addView(updateBtn, LinearLayout.LayoutParams(dp(44), dp(44)))

        contentFrame = FrameLayout(this)
        val contentParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1f
        )

        portalWebView = WebView(this)
        playerWebView = WebView(this)
        aiTutorWebView = WebView(this)

        // Register NativeDownloadBridge & AiTutorBridge BEFORE loading local HTML assets
        configureWebView(
            portalWebView,
            attachDownloadBridge = false,
            attachAiTutorBridge = false,
            enableOAuthPopups = true
        )
        configureWebView(
            playerWebView,
            attachDownloadBridge = true,
            attachAiTutorBridge = false,
            enableOAuthPopups = false
        )
        configureWebView(
            aiTutorWebView,
            attachDownloadBridge = false,
            attachAiTutorBridge = true,
            enableOAuthPopups = false
        )

        contentFrame.addView(portalWebView)
        contentFrame.addView(playerWebView)
        contentFrame.addView(aiTutorWebView)

        root.addView(
            topBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        )
        root.addView(contentFrame, contentParams)
        setContentView(root)

        portalWebView.loadUrl("https://pwskills.com/dashboard/overview/")
        playerWebView.loadUrl("file:///android_asset/player.html")
        aiTutorWebView.loadUrl("file:///android_asset/ai_tutor.html")

        showTab(1001)
        AppUpdater.checkForUpdate(this, silentIfUpToDate = true)
    }

    private fun configureWebView(
        webView: WebView,
        attachDownloadBridge: Boolean,
        attachAiTutorBridge: Boolean,
        enableOAuthPopups: Boolean
    ) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        if (enableOAuthPopups) {
            settings.setSupportMultipleWindows(true)
            settings.javaScriptCanOpenWindowsAutomatically = true
            // Keep native WebView User-Agent untouched so Sec-CH-UA headers match (prevents Google 400 malformed error)
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = AlmaWebViewClient(this)
        webView.webChromeClient = AlmaWebChromeClient(this)

        if (attachDownloadBridge) {
            downloadBridge = NativeDownloadBridge(
                context = this,
                repository = repository,
                providerAdapter = providerAdapter
            )
            webView.addJavascriptInterface(downloadBridge, "NativeDownloadBridge")
        }

        if (attachAiTutorBridge) {
            aiTutorBridge = AiTutorBridge(this, webView)
            webView.addJavascriptInterface(aiTutorBridge, "AiTutorBridge")
        }
    }

    /**
     * Opens an overlay child WebView for OAuth popups (such as Sign in with Google)
     * so window.opener and postMessage callbacks work properly and return to portalWebView.
     */
    fun openPopupWebView(resultMsg: Message): Boolean {
        val popup = WebView(this)
        val settings = popup.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        // Keep native WebView User-Agent untouched so Sec-CH-UA headers match

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(popup, true)

        popup.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()
            }
        }
        popup.webChromeClient = AlmaWebChromeClient(this)

        popup.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        popupWebViews.add(popup)
        contentFrame.addView(popup)

        val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
        transport.webView = popup
        resultMsg.sendToTarget()
        return true
    }

    fun closePopupWebView(popup: WebView) {
        if (popupWebViews.remove(popup)) {
            contentFrame.removeView(popup)
            popup.stopLoading()
            popup.destroy()
            CookieManager.getInstance().flush()
        }
    }

    private fun closeAllPopups() {
        val copy = popupWebViews.toList()
        for (p in copy) {
            closePopupWebView(p)
        }
    }

    private fun createNavButton(title: String, id: Int, bgHex: String): Button {
        return Button(this).apply {
            this.id = id
            this.text = title
            this.textSize = 11.5f
            this.setTextColor(Color.WHITE)
            this.setBackgroundColor(Color.parseColor(bgHex))
            this.setOnClickListener(this@MainActivity)
        }
    }

    override fun onClick(v: View?) {
        val id = v?.id ?: return
        if (id == 1004) {
            AppUpdater.checkForUpdate(this, silentIfUpToDate = false)
            return
        }
        showTab(id)
    }

    private var cachedPortalSyncJs: String? = null

    fun injectPortalSyncBridge(targetView: WebView = portalWebView) {
        val script = cachedPortalSyncJs ?: try {
            assets.open("portal_sync_bridge.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
                .also { cachedPortalSyncJs = it }
        } catch (_: Exception) {
            return
        }
        targetView.evaluateJavascript(script, null)
    }

    private fun showTab(tabId: Int) {
        if (tabId != 1001) {
            closeAllPopups()
        }
        portalWebView.onResume()
        portalWebView.resumeTimers()
        injectPortalSyncBridge(portalWebView)
        portalWebView.visibility = if (tabId == 1001) View.VISIBLE else View.GONE
        playerWebView.visibility = if (tabId == 1002) View.VISIBLE else View.GONE
        aiTutorWebView.visibility = if (tabId == 1003) View.VISIBLE else View.GONE
        pushSessionToChildViews()
    }

    private var lastSyncTimestampMs: Long = 0L
    private var lastSyncSeq: Long = 0L

    fun saveSessionJson(json: String?) {
        if (json.isNullOrBlank()) return
        when (val resolution = ActiveLessonState.resolvePortalSync(json)) {
            is PortalSyncResolution.Confirmed -> {
                val incomingState = resolution.state
                if (incomingState.lastUpdatedAt < lastSyncTimestampMs) return
                if (incomingState.lastUpdatedAt == lastSyncTimestampMs && incomingState.seq < lastSyncSeq) return

                lastSyncTimestampMs = incomingState.lastUpdatedAt
                lastSyncSeq = incomingState.seq
                canonicalLessonState = incomingState
                latestSessionJson = json

                // Register confirmed active lesson in PwPortalProviderAdapter metadata registry
                providerAdapter.registerSyncedLesson(incomingState.toLessonMetadata())
                getSharedPreferences("pw_pm_v21_session", MODE_PRIVATE)
                    .edit()
                    .putString("session_json", json)
                    .apply()
                pushSessionToChildViews()
            }
            is PortalSyncResolution.Unresolved -> {
                if (resolution.lastUpdatedAt < lastSyncTimestampMs) return
                lastSyncTimestampMs = resolution.lastUpdatedAt
                lastSyncSeq = resolution.seq
                // Clear stale lesson context so previous lessonId is never reused!
                canonicalLessonState = null
                latestSessionJson = resolution.toJson().toString()
                getSharedPreferences("pw_pm_v21_session", MODE_PRIVATE)
                    .edit()
                    .remove("session_json")
                    .apply()
                pushSessionToChildViews()
            }
        }
    }

    fun pushSessionToChildViews() {
        if (latestSessionJson.isBlank()) return
        val js = "window.__pwApplySessionState&&window.__pwApplySessionState($latestSessionJson);"
        playerWebView.evaluateJavascript(js, null)
        aiTutorWebView.evaluateJavascript(js, null)
    }

    fun dispatchPortalCommand(cmd: String?) {
        if (cmd.isNullOrBlank()) return
        portalWebView.evaluateJavascript(
            "window.__pwPortalControl&&window.__pwPortalControl('$cmd');",
            null
        )
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onStop() {
        super.onStop()
        CookieManager.getInstance().flush()
    }

    override fun onBackPressed() {
        if (popupWebViews.isNotEmpty()) {
            val topPopup = popupWebViews.last()
            if (topPopup.canGoBack()) {
                topPopup.goBack()
            } else {
                closePopupWebView(topPopup)
            }
            return
        }
        if (portalWebView.visibility == View.VISIBLE && portalWebView.canGoBack()) {
            portalWebView.goBack()
            return
        }
        if (portalWebView.visibility != View.VISIBLE) {
            showTab(1001)
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        closeAllPopups()
        CookieManager.getInstance().flush()
        if (::downloadBridge.isInitialized) {
            downloadBridge.shutdown()
        }
        if (::aiTutorBridge.isInitialized) {
            aiTutorBridge.shutdown()
        }
        if (::offlinePlayer.isInitialized) {
            offlinePlayer.release()
        }
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
