package com.pwskills.mobile.pwpm02

import android.os.Message
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView

/**
 * Standalone File: AlmaWebChromeClient.kt
 * Handles EME protected media permission, PW_SYNC console bridge, and OAuth popups
 * (e.g., Sign in with Google) via onCreateWindow / onCloseWindow.
 */
class AlmaWebChromeClient(private val activity: MainActivity) : WebChromeClient() {
    override fun onPermissionRequest(request: PermissionRequest?) {
        if (request == null) return
        val resources = request.resources ?: emptyArray()
        val granted = resources.filter {
            it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
        }.toTypedArray()
        if (granted.isNotEmpty()) {
            request.grant(granted)
        } else {
            request.deny()
        }
    }

    override fun onCreateWindow(
        view: WebView?,
        isDialog: Boolean,
        isUserGesture: Boolean,
        resultMsg: Message?
    ): Boolean {
        if (resultMsg == null) return false
        return activity.openPopupWebView(resultMsg)
    }

    override fun onCloseWindow(window: WebView?) {
        super.onCloseWindow(window)
        CookieManager.getInstance().flush()
        if (window != null) {
            activity.closePopupWebView(window)
        }
    }

    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
        val msg = consoleMessage?.message() ?: return super.onConsoleMessage(consoleMessage)
        if (msg.startsWith("__PW_SYNC__:") || msg.startsWith("PW_SYNC:")) {
            val payload = msg.removePrefix("__PW_SYNC__:").removePrefix("PW_SYNC:").trim()
            activity.saveSessionJson(payload)
            return true
        }
        if (msg.startsWith("__PW_REQ_SESSION__:")) {
            activity.pushSessionToChildViews()
            return true
        }
        if (msg.startsWith("__PW_CMD__:") || msg.startsWith("PW_CMD:")) {
            val cmd = msg.removePrefix("__PW_CMD__:").removePrefix("PW_CMD:").trim()
            activity.dispatchPortalCommand(cmd)
            return true
        }
        return super.onConsoleMessage(consoleMessage)
    }

    override fun onProgressChanged(view: WebView?, newProgress: Int) {
        super.onProgressChanged(view, newProgress)
    }
}
